document.addEventListener("DOMContentLoaded", function () {
  new Splide("#latest-creations-carousel", {
    type: "loop", // Permet de faire boucler les images
    perPage: 3, // 3 images visibles en même temps
    autoplay: true, // Démarrer automatiquement
    interval: 5000, // Changer les images toutes les 5 secondes
    focus: "center", // Mettre l'image centrale en avant
    gap: "1rem", // Espacement entre les images
    breakpoints: {
      768: {
        perPage: 1, // Affiche 1 image à la fois sur les petits écrans
      },
    },
  }).mount();
});
